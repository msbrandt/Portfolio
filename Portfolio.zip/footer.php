<?php ?>
<!-- start of footer section  -->

<footer id="footer">
	<h4><?php _e( 'Designed and developed by Me!', 'myTheme-domain' ); ?></h4>
</footer>


</div>

	<?php  wp_footer(); ?>

</body>
</html>
<?php ?>